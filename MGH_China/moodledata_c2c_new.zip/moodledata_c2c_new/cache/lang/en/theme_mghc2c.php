<?php $this->cache['en']['theme_mghc2c'] = array (
  'pluginname' => 'Mghc2c',
  'region-side-post' => 'Right',
  'region-side-pre' => 'Left',
  'choosereadme' => 'This theme is a very basic white theme, with a minimum amount of CSS added to the base theme to make it actually usable.',
);