<?php $this->cache['en']['core_license'] = array (
  'allrightsreserved' => 'All rights reserved',
  'cc' => 'Creative Commons',
  'cc-nc' => 'Creative Commons - No Commercial',
  'cc-nc-nd' => 'Creative Commons - No Commercial NoDerivs',
  'cc-nc-sa' => 'Creative Commons - No Commercial ShareAlike',
  'cc-nd' => 'Creative Commons - NoDerivs',
  'cc-sa' => 'Creative Commons - ShareAlike',
  'public' => 'Public domain',
  'unknown' => 'Other',
);