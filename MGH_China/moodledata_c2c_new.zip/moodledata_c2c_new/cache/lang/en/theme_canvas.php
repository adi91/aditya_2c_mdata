<?php $this->cache['en']['theme_canvas'] = array (
  'pluginname' => 'Canvas',
  'region-side-post' => 'Right',
  'region-side-pre' => 'Left',
  'choosereadme' => 'Canvas, a Moodle 2.0 parent theme by Patrick Malley.',
);