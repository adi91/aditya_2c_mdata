<?php $this->cache['en']['tool_replace'] = array (
  'pluginname' => 'DB search and replace',
);