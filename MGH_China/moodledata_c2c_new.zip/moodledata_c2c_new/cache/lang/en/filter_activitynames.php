<?php $this->cache['en']['filter_activitynames'] = array (
  'filtername' => 'Activity names auto-linking',
);