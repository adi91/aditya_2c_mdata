<?php $this->cache['en']['repository_local'] = array (
  'configplugin' => 'Configuration for server file repository',
  'currentusefiles' => 'Currently used files',
  'emptyfilelist' => 'There are no files to show',
  'local:view' => 'View server repository',
  'notitle' => 'notitle',
  'remember' => 'Remember me',
  'pluginname_help' => 'Files previously uploaded to the Moodle server',
  'pluginname' => 'Server files',
);