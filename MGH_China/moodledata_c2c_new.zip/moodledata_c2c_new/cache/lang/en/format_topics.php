<?php $this->cache['en']['format_topics'] = array (
  'sectionname' => 'Topic',
  'pluginname' => 'Topics format',
  'section0name' => 'General',
  'page-course-view-topics' => 'Any course main page in topics format',
  'page-course-view-topics-x' => 'Any course page in topics format',
);