<?php $this->cache['en']['block_html'] = array (
  'configcontent' => 'Content',
  'configtitle' => 'Block title',
  'leaveblanktohide' => 'leave blank to hide the title',
  'newhtmlblock' => '(new HTML block)',
  'pluginname' => 'HTML',
);