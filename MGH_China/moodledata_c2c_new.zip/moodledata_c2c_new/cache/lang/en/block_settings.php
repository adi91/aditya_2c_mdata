<?php $this->cache['en']['block_settings'] = array (
  'enabledock' => 'Allow the user to dock this block',
  'pluginname' => 'Settings',
);