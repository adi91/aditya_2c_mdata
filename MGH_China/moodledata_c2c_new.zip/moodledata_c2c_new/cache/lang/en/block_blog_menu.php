<?php $this->cache['en']['block_blog_menu'] = array (
  'pluginname' => 'Blog menu',
);