<?php $this->cache['en']['core_table'] = array (
  'downloadas' => 'Download table data as',
  'downloadcsv' => 'a comma separated values text file',
  'downloadexcel' => 'a Microsoft Excel spreadsheet',
  'downloadods' => 'an OpenDocument Spreadsheet (ODS)',
  'downloadtsv' => 'a tab separated values text file',
  'downloadxhtml' => 'an unpaged XHTML document',
);