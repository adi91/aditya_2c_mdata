<?php $this->cache['en']['auth_manual'] = array (
  'auth_manualdescription' => 'This method removes any way for users to create their own accounts.  All accounts must be manually created by the admin user.',
  'pluginname' => 'Manual accounts',
);