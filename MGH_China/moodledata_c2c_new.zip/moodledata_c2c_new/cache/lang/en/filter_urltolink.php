<?php $this->cache['en']['filter_urltolink'] = array (
  'embedimages' => 'Embed images',
  'embedimages_desc' => 'Replace image urls with images in selected text formats.',
  'filtername' => 'Convert URLs into links and images',
  'settingformats' => 'Apply to formats',
  'settingformats_desc' => 'The filter will be applied only if the original text was inserted in one of the selected formats.',
);