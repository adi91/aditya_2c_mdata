<?php $this->cache['en']['repository_alfresco'] = array (
  'alfresco_url' => 'Alfresco URL',
  'alfrescourltext' => 'Afresco API url should be: http://yoursite.com/alfresco/api',
  'alfresco:view' => 'View alfresco repository',
  'configplugin' => 'Alfresco configuration',
  'notitle' => 'notitle',
  'password' => 'Password',
  'pluginname_help' => 'A plug-in for Alfresco CMS',
  'pluginname' => 'Alfresco repository',
  'soapmustbeenabled' => 'SOAP extension must be enabled for alfresco plugin',
  'username' => 'User name',
);