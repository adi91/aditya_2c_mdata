<?php $this->cache['en']['tool_health'] = array (
  'healthnoproblemsfound' => 'There is no health problem found!',
  'healthproblemsdetected' => 'Health problems detected!',
  'healthproblemsolution' => 'Health problem solution',
  'healthreturntomain' => 'Continue',
  'healthsolution' => 'Solution',
  'pluginname' => 'Health center',
);