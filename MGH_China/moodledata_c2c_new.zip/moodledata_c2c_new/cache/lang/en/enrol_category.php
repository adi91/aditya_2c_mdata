<?php $this->cache['en']['enrol_category'] = array (
  'category:synchronised' => 'Role assignments synchronised to course enrolment',
  'pluginname' => 'Category enrolments',
  'pluginname_desc' => 'Category enrolment plugin is a legacy solution for enrolments at the course category level via role assignments. It is recommended to use cohort synchronisation instead.',
);