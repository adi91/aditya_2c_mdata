<?php $this->cache['en']['block_course_overview'] = array (
  'pluginname' => 'Course overview',
);