<?php $this->cache['en']['report_questioninstances'] = array (
  'editquestionshere' => 'Edit questions in this context',
  'getreport' => 'Get the report',
  'hiddenquestions' => 'Hidden',
  'intro' => 'This report lists all the contexts in the system where there are questions of a particular type.',
  'pluginname' => 'Question instances',
  'questioninstances:view' => 'View question instances report',
  'reportforallqtypes' => 'Report for all question types',
  'reportformissingqtypes' => 'Report for question of unknown types',
  'reportforqtype' => 'Report for question type \'{$a}\'',
  'reportsettings' => 'Report settings',
  'totalquestions' => 'Total',
  'visiblequestions' => 'Visible',
);