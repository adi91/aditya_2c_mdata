<?php $this->cache['en']['report_outline'] = array (
  'outline:view' => 'View activity report',
  'page-report-outline-x' => 'Any outline report',
  'page-report-outline-index' => 'Course outline report',
  'page-report-outline-user' => 'User course outline report',
  'pluginname' => 'Activity report',
);