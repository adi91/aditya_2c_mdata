<?php $this->cache['en']['block_calendar_month'] = array (
  'pluginname' => 'Calendar',
);