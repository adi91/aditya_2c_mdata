<?php $this->cache['en']['filter_emoticon'] = array (
  'filtername' => 'Display emoticons as images',
  'settingformats' => 'Apply to formats',
  'settingformats_desc' => 'The filter will be applied only if the original text was inserted in one of the selected formats.',
);