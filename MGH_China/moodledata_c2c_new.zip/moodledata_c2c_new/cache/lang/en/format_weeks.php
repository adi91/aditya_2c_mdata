<?php $this->cache['en']['format_weeks'] = array (
  'sectionname' => 'Week',
  'pluginname' => 'Weekly format',
  'section0name' => 'General',
  'page-course-view-weeks' => 'Any course main page in weeks format',
  'page-course-view-weeks-x' => 'Any course page in weeks format',
);