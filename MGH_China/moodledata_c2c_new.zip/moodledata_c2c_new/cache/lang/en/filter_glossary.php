<?php $this->cache['en']['filter_glossary'] = array (
  'filtername' => 'Glossary auto-linking',
);