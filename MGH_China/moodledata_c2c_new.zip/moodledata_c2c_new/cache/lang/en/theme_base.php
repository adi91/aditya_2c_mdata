<?php $this->cache['en']['theme_base'] = array (
  'pluginname' => 'Base',
  'region-side-post' => 'Right',
  'region-side-pre' => 'Left',
  'choosereadme' => 'Base is a special minimalist theme with only basic layout. It is intended as a starting point for other themes to build upon.  It is not recommend to actually choose this theme for production sites!',
);