<?php $this->cache['en']['mod_label'] = array (
  'labeltext' => 'Label text',
  'modulename' => 'Label',
  'modulename_help' => 'A label enables text and images to be inserted among the activity links on the course page.',
  'modulenameplural' => 'Labels',
  'pluginadministration' => 'Label administration',
  'pluginname' => 'Label',
);