<?php $this->cache['en']['block_participants'] = array (
  'pluginname' => 'People',
);