<?php $this->cache['en']['auth_none'] = array (
  'auth_nonedescription' => 'Users can sign in and create valid accounts immediately, with no authentication against an external server and no confirmation via email.  Be careful using this option - think of the security and administration problems this could cause.',
  'pluginname' => 'No authentication',
);