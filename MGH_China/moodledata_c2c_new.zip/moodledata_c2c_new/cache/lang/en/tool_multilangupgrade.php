<?php $this->cache['en']['tool_multilangupgrade'] = array (
  'multilangupgradeinfo' => 'The multilang filter syntax was changed in 1.8, &lt;lang&gt; tag is not supported any more. <br /><br />Example: &lt;span lang="en" class="multilang">Hello!&lt;/span&gt;&lt;span lang="es" class="multilang">Hola!&lt;/span&gt;<br /><br /><strong>Do you want to upgrade the syntax in all existing texts now?</strong>',
  'pluginname' => 'Multilang upgrade',
);