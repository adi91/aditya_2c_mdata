<?php $this->cache['en']['block_online_users'] = array (
  'configtimetosee' => 'Number of minutes determining the period of inactivity after which a user is no longer considered to be online.',
  'online_users:viewlist' => 'View list of online users',
  'periodnminutes' => 'last {$a} minutes',
  'pluginname' => 'Online users',
  'timetosee' => 'Remove after inactivity (minutes)',
);